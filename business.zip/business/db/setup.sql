CREATE TABLE members (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(30) NOT NULL,
    email VARCHAR(50) NOT NULL,
    password CHAR(128) NOT NULL
) ENGINE = InnoDB;

CREATE TABLE login_attempts (
    user_id INT(11) NOT NULL,
    time VARCHAR(30) NOT NULL
) ENGINE=InnoDB;

CREATE TABLE courses (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    coursename VARCHAR(80) NOT NULL,
    price DECIMAL(5,2) NOT NULL,
    starttime VARCHAR(80) NOT NULL,
	place VARCHAR(80) NOT NULL,
	image VARCHAR(100) NOT NULL,
	sku VARCHAR(50) NOT NULL,
	remarks VARCHAR(300) NOT NULL,
	available BOOLEAN NOT NULL,
	friend VARCHAR(20),
	fee VARCHAR(20),
	levels VARCHAR(20),
	offsite VARCHAR(20)
) ENGINE=InnoDB;

CREATE TABLE orders (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
	userid INT NOT NULL,
	courseid INT NOT NULL,
	FOREIGN KEY (userid)
        REFERENCES members(id),
	FOREIGN KEY (courseid)
        REFERENCES courses(id),
    qty INT NOT NULL
) ENGINE=InnoDB;
